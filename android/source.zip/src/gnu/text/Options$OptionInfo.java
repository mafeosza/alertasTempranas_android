// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package gnu.text;


// Referenced classes of package gnu.text:
//            Options

public static final class 
{

    Object defaultValue;
    String documentation;
    String key;
    int kind;
     next;

    public ()
    {
    }
}
