// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package gnu.bytecode;


// Referenced classes of package gnu.bytecode:
//            Attribute

public interface AttrContainer
{

    public abstract Attribute getAttributes();

    public abstract void setAttributes(Attribute attribute);
}
