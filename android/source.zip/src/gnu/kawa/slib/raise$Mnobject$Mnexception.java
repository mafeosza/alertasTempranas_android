// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package gnu.kawa.slib;


// Referenced classes of package gnu.kawa.slib:
//            srfi34

public class value extends Throwable
{

    public Object value;

    public (Object obj)
    {
        value = obj;
    }
}
